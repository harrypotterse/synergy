<?php
define('Page', 'الاعلانات');
define('Table', 'ads');
define('Link', 'https://image.flaticon.com/icons/svg/1986/1986476.svg');
define('label', 'label label-success');
define('track', '../../../Public/ads/');
?>