<div class="btn-group btn-group-justified">
    <a href="addition.php" class="btn btn-primary bg-maroon">اضافة موضوع جديد</a>
    <a href="../home/spreadsheet.php" class="btn btn-primary bg-purple ">الرئسية</a>
    <a href="../../../index.php" class="btn btn-primary bg-orange  ">العودة الي الموقع</a>
</div>