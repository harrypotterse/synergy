<?php
define('Page', 'الخدمات');
define('Table', 'services');
define('Link', 'https://image.flaticon.com/icons/svg/994/994373.svg');
define('label', 'label label-success');
define('track', '../../../Public/services/');
?>